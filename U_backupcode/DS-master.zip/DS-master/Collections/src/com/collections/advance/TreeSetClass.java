package com.collections.advance;

import java.util.Set;
import java.util.TreeSet;

public class TreeSetClass {

	public static void main(String[] args) {
		
		Set s = new TreeSet();
		
		s.add(1);
		s.add(null);//NullPointerException
		
	}
	
}
