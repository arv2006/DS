package com.collectios.basics;

public class StringCompare {

	public static void main(String[] args) {
		
		String s = "hello";
		
		System.out.println(s.compareTo("hi"));
		
	}
	

}
