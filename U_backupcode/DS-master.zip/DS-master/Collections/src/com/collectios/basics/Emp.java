package com.collectios.basics;

public class Emp {

}
