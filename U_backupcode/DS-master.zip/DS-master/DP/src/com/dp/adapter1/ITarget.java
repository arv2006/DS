package com.dp.adapter1;

public interface ITarget {

	public void processCompanySalary(String[][] employeeinfo);
	
}
