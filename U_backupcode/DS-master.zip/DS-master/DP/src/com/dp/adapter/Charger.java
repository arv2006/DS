package com.dp.adapter;

public interface Charger {

	public void setMobileName(String mobileName);
	public void supplyCharge();
}
