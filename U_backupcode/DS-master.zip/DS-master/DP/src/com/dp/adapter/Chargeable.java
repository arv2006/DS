package com.dp.adapter;

public interface Chargeable {

	public void setMobileName(String mobileName);
	public void charge();
}
