package com.dp.state.contextstate;

public interface State {

	public void doAction();
}
