package com.oops.interfaceabstart;

public class C extends B{

	@Override
	public void show1() {
		
	}

	@Override
	public void show2() {
		
	}

	@Override
	public void show5() {
		// TODO Auto-generated method stub
		
	}
	
	
	
}
