package com.oops.interfaceabstart;

public interface A {

	public void show1();
	public void show2();
	public void show3();
	
}
