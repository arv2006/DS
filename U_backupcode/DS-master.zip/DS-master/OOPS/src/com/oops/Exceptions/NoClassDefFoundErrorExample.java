package com.oops.Exceptions;

public class NoClassDefFoundErrorExample {

    public static void main(String[] args) {

        A obj = new A();
    }
}

class A {}