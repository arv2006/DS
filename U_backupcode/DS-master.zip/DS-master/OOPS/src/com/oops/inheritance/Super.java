package com.oops.inheritance;

public class Super {
	
	public Super() {
		System.out.println("Super Cons");
	}

	{
		System.out.println("Super Instance Block");
	}
	
	static{
		System.out.println("Super Static Block");
	}
}
