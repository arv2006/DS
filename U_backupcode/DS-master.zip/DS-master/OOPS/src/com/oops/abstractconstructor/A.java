package com.oops.abstractconstructor;

public abstract class A {

	private int i=10;
	
	private	A(){  //public, protected, 
		
	}

private void show(){
	
}

//private abstract void show1(); // Not possible

//final abstract void show2(); // Not possible

}
