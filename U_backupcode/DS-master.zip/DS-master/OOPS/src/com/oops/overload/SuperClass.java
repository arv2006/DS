package com.oops.overload;

public class SuperClass {
	
	public void hello(int i) {
		
		System.out.println("Super");
	}

}
