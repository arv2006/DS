package com.oops.override;

public class Sup {

	void hello()
	{
		System.out.println("Super !!!");
	}
	
	void hello(int i, int j)
	{
		System.out.println("Sup int i ,int i ----!!!");
	}
}
