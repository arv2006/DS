package com.oops.override;

public abstract class AbstractClass {

	private AbstractClass(){}
	
//	private abstract void show();
	
}
