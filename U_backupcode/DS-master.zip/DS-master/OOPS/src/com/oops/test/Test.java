package com.oops.test;

public class Test {

	enum color{RED, BLUE,WHITE,GREEN,YELLOW};
	
	void m1(String type)
	{
		
	}
}
