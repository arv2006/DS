package com.oops.finaltest;

public class C extends B{

	/*void show1(){
		
	}*/  // Not Possible as it is final in class B

		//OR
	
	/*static void show1(){
	
	}*/  // Not Possible as it is final in class B


}
