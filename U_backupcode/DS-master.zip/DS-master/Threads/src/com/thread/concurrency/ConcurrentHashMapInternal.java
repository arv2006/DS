package com.thread.concurrency;

import java.util.Map;
import java.util.concurrent.*;

public class ConcurrentHashMapInternal {

	public static void main(String[] args) {
		System.out.println("Hello");
		ConcurrentHashMap<String,Integer> conHashMap = new ConcurrentHashMap<String,Integer>();
		System.out.println(conHashMap);
		
	}
	
}
