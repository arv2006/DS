package com.thread.locks;

import java.util.concurrent.locks.Lock;

public class Counter {


	String s = new String("Hello");
	
	
	
}
