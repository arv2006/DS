package com.ds.trees;

public class Temp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println(0 > -1);
	}

}
