package main.java.com.joeblau.ecs.impl.enums;

/**
 * Created with IntelliJ IDEA.
 * User: josephblau
 * Date: 8/22/13
 * Time: 9:51 AM
 * To change this template use File | Settings | File Templates.
 */
public enum ElevatorStatus {
  ELEVATOR_OCCUPIED,
  ELEVATOR_EMPTY;
}
