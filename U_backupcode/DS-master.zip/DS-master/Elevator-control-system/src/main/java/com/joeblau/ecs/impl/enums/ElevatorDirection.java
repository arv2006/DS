package main.java.com.joeblau.ecs.impl.enums;

/**
 * Created with IntelliJ IDEA.
 * User: josephblau
 * Date: 8/22/13
 * Time: 10:12 AM
 * To change this template use File | Settings | File Templates.
 */
public enum ElevatorDirection {
  ELEVATOR_UP,
  ELEVATOR_DOWN,
  ELEVATOR_HOLD
}
