package methodreference;

interface Messageable{  
    Message getMessage(String msg);  
} 