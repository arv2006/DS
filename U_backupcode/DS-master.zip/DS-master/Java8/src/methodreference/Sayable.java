package methodreference;

public interface Sayable {

	void say();
}
