package methodreference;

public interface Hello {

	public void hi();
}
