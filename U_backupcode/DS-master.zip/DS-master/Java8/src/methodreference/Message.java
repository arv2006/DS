package methodreference;

public class Message {
	Message(String msg){  
        System.out.print(msg);  
    }  

}
