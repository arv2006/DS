package metaspace;

public class ClassAImpl implements ClassA {
	
	public void method(String name) {
		// do nothing
	}
}
