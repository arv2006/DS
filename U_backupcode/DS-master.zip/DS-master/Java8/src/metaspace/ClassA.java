package metaspace;

public interface ClassA
{
	void method(String input);
}
